/**
 * 
 */
package com.ms.service;

import java.util.List;

import com.ms.binding.CreatePost;
import com.ms.entity.Post;

/**
 * @author Sawant
 *
 */
public interface PostService {
	
	public List<Post> getPosts();
	
	public boolean addPost(CreatePost form);
	
	public Post updatePost(Post form);
	
	public void deletePost(Integer postId);
	
	public Post getPostByID(Integer postId);
	
	public CharSequence getPostByTitle(String title);
	
}
