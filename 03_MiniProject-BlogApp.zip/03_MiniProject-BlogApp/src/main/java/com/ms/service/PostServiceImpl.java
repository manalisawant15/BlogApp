/**
 * 
 */
package com.ms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ms.binding.CreatePost;
import com.ms.entity.Post;
import com.ms.entity.UserEntity;
import com.ms.repository.PostRepository;
import com.ms.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

/**
 * @author Sawant
 *
 */
@Service
public class PostServiceImpl implements PostService {

	@Autowired
	private PostRepository postRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private HttpSession session;
	
	@Override
	public List<Post> getPosts() {
		
		return postRepo.findAll();
	}

	@Override
	public boolean addPost(CreatePost form) {
		Post entity = new Post();
		BeanUtils.copyProperties(form, entity);
		Integer userId = (Integer) session.getAttribute("userId");
		UserEntity userEntity = userRepo.findById(userId).get();
		entity.setUser(userEntity);
		postRepo.save(entity);
		return true;
	}

	@Override
	public void deletePost(Integer postId) {
		postRepo.deleteById(postId);
	}
	
	@Override
	public Post getPostByID(Integer postId) {
		
		Optional<Post> optional = postRepo.findById(postId);
		Post post = null;
		if(optional.isPresent())
		{
			post = optional.get();
		}
		return post;
	}

	@Override
	public Post updatePost(Post form) {
		Post p = new Post();
		BeanUtils.copyProperties(form, p);
		postRepo.save(p);
//		Optional<Post> post  = Optional.of(this.getPostByID(p.getPostId()));
//		if(post.isPresent()) {
//			p.setPostId(p.getPostId());
//			p.setTitle(form.getTitle());
//			p.setDescription(form.getDescription());
//			p.setContent(form.getContent());
//			postRepo.save(p);
//		}
		return p;
	}

	@Override
	public CharSequence getPostByTitle(String title) {
		
		return (CharSequence) postRepo.findPostByTitle(title);
	}

	
	

}
