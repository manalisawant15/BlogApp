/**
 * 
 */
package com.ms.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ms.binding.LoginForm;
import com.ms.binding.SignupForm;
import com.ms.entity.UserEntity;
import com.ms.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

/**
 * @author Sawant
 *
 */
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private HttpSession session;
	
	@Override
	public String login(LoginForm form) {
		
		UserEntity entity =
				userRepo.findByEmailAndPwd(form.getEmail(), form.getPwd());
		
		if(entity==null) 
		{
			return "Invalid Credentials";
		}
		//create session and store user data in session
		session.setAttribute("userId", entity.getUserId());
		return "success";
	}

	@Override
	public boolean SignUp(SignupForm form) {
		UserEntity user = userRepo.findByEmail(form.getEmail());
 		if(user != null) {
 			return false;
 		}
 		UserEntity entity = new UserEntity();
		BeanUtils.copyProperties(form, entity);
		userRepo.save(entity);
		
		return false;
	}

}
