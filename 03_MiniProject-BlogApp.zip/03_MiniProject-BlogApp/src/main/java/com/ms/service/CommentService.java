/**
 * 
 */
package com.ms.service;

import java.util.List;

import com.ms.binding.CreateComment;
import com.ms.entity.Comment;

/**
 * @author Sawant
 *
 */
public interface CommentService {
	
	public List<Comment> getAllComments(); 
	
	public boolean addComment(Comment form);

	public void deleteComment(Integer id);

	
}
