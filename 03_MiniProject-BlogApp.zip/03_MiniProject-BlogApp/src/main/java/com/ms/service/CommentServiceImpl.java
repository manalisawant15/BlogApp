/**
 * 
 */
package com.ms.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ms.entity.Comment;
import com.ms.repository.CommentRepository;

/**
 * @author Sawant
 *
 */
@Service
public class CommentServiceImpl implements CommentService {

	@Autowired
	private CommentRepository commentRepo;
	
	@Override
	public List<Comment> getAllComments() {
		
		return commentRepo.findAll();
	}

	@Override
	public boolean addComment(Comment form) {
		Comment comment =new Comment();
		//BeanUtils.copyProperties(form, comment);
		comment.getPost();
		commentRepo.save(comment);
		
		return true;
	}

	@Override
	public void deleteComment(Integer id) {
		
		commentRepo.deleteById(id);
	}

}
