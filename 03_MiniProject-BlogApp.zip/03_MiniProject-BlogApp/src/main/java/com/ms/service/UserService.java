/**
 * 
 */
package com.ms.service;

import com.ms.binding.LoginForm;
import com.ms.binding.SignupForm;

/**
 * @author Sawant
 *
 */
public interface UserService {

	public String login(LoginForm form);
	
	public boolean SignUp(SignupForm form);
}
