/**
 * 
 */
package com.ms.binding;

import lombok.Data;


/**
 * @author Sawant
 *
 */
@Data
public class SignupForm {
	
	private String fName;
	
	private String lName;
	
	private String email;

	private String pwd;
}
