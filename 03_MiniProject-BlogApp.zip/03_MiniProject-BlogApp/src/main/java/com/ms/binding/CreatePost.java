/**
 * 
 */
package com.ms.binding;

import lombok.Data;

/**
 * @author Sawant
 *
 */
@Data 
public class CreatePost {

	private String title; 
	
	private String description;
	
	private String content;
}
