/**
 * 
 */
package com.ms.binding;

import lombok.Data;

/**
 * @author Sawant
 *
 */
@Data
public class CreateComment {
	
	private String name;
	
	private String email;
	
	private String content;

}
