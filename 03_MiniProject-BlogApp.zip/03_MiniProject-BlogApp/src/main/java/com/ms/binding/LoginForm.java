/**
 * 
 */
package com.ms.binding;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Sawant
 *
 */
@Setter
@Getter
@Data
public class LoginForm {

	private String email;
	
	private String pwd;
}
