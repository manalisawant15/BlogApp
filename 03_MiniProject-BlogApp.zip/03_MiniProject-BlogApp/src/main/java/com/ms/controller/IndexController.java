/**
 * 
 */
package com.ms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ms.entity.Post;
import com.ms.service.PostService;


/**
 * @author Sawant
 *
 */
@Controller
public class IndexController {
	
	@Autowired
	private PostService postService;
	
	@GetMapping("/")
	public String homePage(Model model) 
	{
		List<Post> posts = postService.getPosts();
		model.addAttribute("post", posts);
		
		return "index";
	}
	
	
}
