/**
 * 
 */
package com.ms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.ms.binding.LoginForm;
import com.ms.binding.SignupForm;
import com.ms.service.UserService;

import jakarta.servlet.http.HttpSession;

/**
 * @author Sawant
 *
 */
@Controller
public class UserController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private HttpSession session;
	
	@GetMapping("/login")
	public String loginPage(Model model) 
	{
		model.addAttribute("loginForm", new LoginForm());
		return "login";
	}
	@PostMapping("/login")
	public String login(@ModelAttribute("loginForm") LoginForm form,Model model) 
	{
		System.out.println(form);
		String login =userService.login(form);
		if(login.contains("success")) {
			return "redirect:/post";
		}
		
		model.addAttribute("errMsg", login);
		return "login";
	}

	@GetMapping("/signup")
	public String signUpPage(Model model) {
		
		model.addAttribute("user",new SignupForm());
		return "signup";
	}
	
	@PostMapping("/signup")
	public String signup(@ModelAttribute("user") SignupForm form, Model model) {
		boolean status = userService.SignUp(form);
		if(status) 
		{
			model.addAttribute("succMsg", "Account Created");
		}else
		{
			model.addAttribute("errMsg", "Choose Unique Email");
		}
		
		return "signup";
	}
	
	@GetMapping("dashboard")
	public String dasboard() {
		
		return "dashboard";
	}
	
	@GetMapping("/logout")
	public String logout() {
		session.invalidate();
		return "redirect:/";
	}
}
