/**
 * 
 */
package com.ms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.ms.binding.CreateComment;
import com.ms.entity.Comment;
import com.ms.service.CommentService;

/**
 * @author Sawant
 *
 */
@Controller
public class CommentController {
	
	@Autowired
	private CommentService commentService;
	
	@GetMapping("/viewcomment")
	public String getComments(Model model)
	{
		List<Comment> comment = commentService.getAllComments();
		model.addAttribute("comment", comment);
		return "viewcomment";
	}
	
	@GetMapping("deletecomment/{commentId}")
	public String deleteComment(@PathVariable("commentId") Integer commentId) {
		commentService.deleteComment(commentId);
		return "redirect:/viewcomment";
	}

	@GetMapping("/addcomment")
	public String addCommentPage(Model model) {
		CreateComment comment = new CreateComment();
		model.addAttribute("comment", comment);
		
		return "/postdetails";
	}
	
	@PostMapping("/addcomment")
	public String addComment(@ModelAttribute("comment") Comment comment ,Model model) {
		boolean status = commentService.addComment(comment);
		if(status) {
			model.addAttribute("succMsg", "Comment Added");
		}
		else {
			model.addAttribute("errMsg", "Not Saved");
		}
		//model.addAttribute("comments", comment);
		return "postdetails";
	}
}
