/**
 * 
 */
package com.ms.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.ms.binding.CreateComment;
import com.ms.binding.CreatePost;
import com.ms.entity.Post;
import com.ms.service.PostService;

/**
 * @author Sawant
 *
 */
@Controller
public class PostController {

	@Autowired
	private PostService postService;
	
	@GetMapping("/post")
	public String postPage(Model model) {
		List<Post> posts = postService.getPosts();
		model.addAttribute("post", posts);
		return "post";
	}
	
	@GetMapping("/addpost")
	public String createPostPage(Model model) {
		CreatePost post =new CreatePost();
		model.addAttribute("post", post);
		return "createpost";
	}
	
	@PostMapping("/addpost")
	public String createPost(@ModelAttribute("post") CreatePost post, Model model) {
		System.out.println(post);
		boolean status = postService.addPost(post);
		if(status) {
			model.addAttribute("succMsg", "Enquiry Added");
		}
		else {
		model.addAttribute("errMsg", "PRoblem Occured");
		}
		return "createpost";
	}
	
	@GetMapping("/delete/{id}")
	public String deletePost(@PathVariable("id") Integer postId) {
		//call post delete method
		this.postService.deletePost(postId);
		return "redirect:/post";
	}
	
	@GetMapping("/update/{postId}")
	public String updatePostPage(@PathVariable("postId") Integer postId,Model model) {
		//get post from service
		Post post = postService.getPostByID(postId);
		//set post as model attribute to pre-populate the form
		model.addAttribute("post", post);
		
		return "updatepost";
	}
	@PostMapping("/update/{postId}")
	public String updatePost(@PathVariable("postId") Integer postId,Model model,@ModelAttribute("post") Post post) {
		Post p = postService.getPostByID(postId);
		
		p.setPostId(postId);
		p.setTitle(post.getTitle());
		p.setDescription(post.getDescription());
		p.setContent(post.getContent());
		p.getCreatedOn();
	//	p.setCreatedOn(post.getCreatedOn());
		postService.updatePost(p);
		model.addAttribute("post", p);
		return "redirect:/post";
		
	}
	
	@GetMapping
	public String searchPost(@PathVariable String title,Model model) {
		List<Post> post =null;
		
		List<Post> search = post.stream().filter(e ->e.getTitle().toLowerCase().contains(postService.getPostByTitle(title))).collect(Collectors.toList());
			//	.collect(Collectors.toList());
		model.addAttribute("title", search);
		return "postdetails";
	}
	
	@GetMapping("/postdetails/{postId}")
	public String getPostDetailsByPostId(@PathVariable("postId") Integer postId,Model model) {
		
		Post post = postService.getPostByID(postId);
		model.addAttribute("post", post);
		CreateComment comment = new CreateComment();
		model.addAttribute("comment", comment);
		return "/postdetails";
	}
}
