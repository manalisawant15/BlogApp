/**
 * 
 */
package com.ms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ms.entity.Post;

/**
 * @author Sawant
 *
 */
public interface PostRepository extends JpaRepository<Post, Integer> {

	public Post findPostByTitle(String title);
}
