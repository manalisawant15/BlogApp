/**
 * 
 */
package com.ms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ms.entity.UserEntity;

/**
 * @author Sawant
 *
 */
public interface UserRepository extends JpaRepository<UserEntity, Integer>{


	public UserEntity findByEmailAndPwd(String email, String pwd);

	public UserEntity findByEmail(String email);
}
