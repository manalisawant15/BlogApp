/**
 * 
 */
package com.ms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ms.entity.Comment;

/**
 * @author Sawant
 *
 */
public interface CommentRepository extends JpaRepository<Comment, Integer>{

}
